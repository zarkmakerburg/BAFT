# تحویل امضای مستقل v0.4.0 برای macOS

وضعیت نهایی: main برابر `9c32ba369fe2be2c549f2878d1de5dbf092c8f64` با tree `e065727d66ce97a917b9fc64e4e7ec7db9d73e3c` است؛ tag تغییرناپذیر `v0.4.0` به همین SHA اشاره می‌کند. تمام۱۳workflow/۲۸job لازم و تمام۱۹workflow آخر main موفق‌اند. workflow رسمی [41046337283](https://github.com/zarkmakerburg/BAFT/actions/runs/41046337283)، با event=push و tag=v0.4.0، candidate بدون امضا را موفق ساخت. هر۱۰asset رسمی بایت‌به‌بایت با build مستقل و root/revocation/installer/notices با source همینSHA مطابق‌اند. `CANDIDATE` رسمی و APPROVAL نهایی برای امضای مستقل در این بسته قرار دارند. **امضای واقعی، اجرای native روی Mac و انتشار هنوز انجام نشده‌اند.**

مجوز merge/tag/release قبلاً داده شده است؛ درخواست تکرار اجازه لازم نیست. اجرای موجودِ کلید release روی دستگاه مستقل تنها بخش خارجی این تحویل است. کلید خصوصی، root خصوصی یا گواهی جایگزین در این کار ساخته نشده است.

## فایل قابل تحویل و راهنمای کوتاه

نسخهٔ نهایی این تحویل در پوشهٔ داخل archive: `BAFT-v0.4.0-macOS-signing`. [راهنمای فارسی سه‌مرحله‌ای](README-FA.md) شامل نصب ابزارهای عمومی، یک دستور و بازگرداندن فقط `signed-public-only.tar.gz` است. CPU مک با `uname -m` تشخیص داده می‌شود؛ سؤال دیگری دربارهٔ مدل لازم نیست.

بسته فقط شامل این فایل‌های عمومی است: ۱۰ artifact unsigned، installer، root عمومی و revocation، سه notice، metadata/provenance و گزارش‌های بازبینی، source حداقلی signer بررسی‌شده، دو binary اختیاری Darwin و wrapper/validator. source حداقلی فقط ۶ فایل ثابت دارد و هیچ تست یا signing-fixture private key همراه آن نیست. کلید یا گواهی خصوصی/محلی کاربر هرگز وارد بسته نمی‌شود.

## مرجع مستقل signer

اسناد موجود pin قبلیِ `TRUSTED_SIGNER_SHA` تعیین نکرده بودند. پس از **بازبینی مستقل تازه**، مرجع پیشنهادی این تحویل `94c55dccf5af7cd126089374d991463931413121` است؛ این انتخاب به معنی وجود تأیید تاریخی مالک برای این pin نیست. [گزارش source](proof/TRUSTED-SIGNER-REVIEW.md) و [بازبینی wrapper](proof/MACOS-WRAPPER-REVIEW.md) موجودند.

کد `cmd/baft-release`، `internal/release`، helperها و سند signing بین old main و نامزد یکسان است؛ فقط Go directive در main جدید `1.27.3` است. signer قدیمی با Go 1.27.3 ساخته می‌شود. source importها فقط standard library و همان package داخلی‌اند؛ network، subprocess یا اجرای artifact ندارند. sign صرفاً کلید انتخاب‌شده را می‌خواند و سه metadata عمومی می‌نویسد. verify اجباری پس از sign، revocation و زمان معتبر گواهی را کنترل می‌کند.

| خروجی مستقل Go 1.27.3 | SHA-256 |
|---|---|
| Darwin arm64 | `6a62824f4140a55562fdfe9a784f7b14f36c10031f5ea23fa04585e62646fa50` |
| Darwin amd64 | `34b8400e2c3416d5fd8cb513c647d3bdb49d132a8c55868010210535e3a1bd72` |
| Linux amd64 برای verify در HQ | `5429e8333c68df3e7dc0058cc2f106ea7bff4bcbce82304006be2021c29e0339` |

فرمت دو فایل Darwin با `file`، Mach-O arm64/x86_64 تشخیص داده شد. بازسازی از source حداقلی داخل بسته نیز بایت‌به‌بایت با build از Git archive کامل مطابق بود. خود binaryهای Darwin روی Linux اجرا نشده‌اند. wrapper به‌طور پیش‌فرض signer را **محلی** روی Mac از همین source ثابت می‌سازد و hash آن را کنترل می‌کند؛ binary دانلودشده یا helper نامزد کنار کلید اجرا نمی‌شود و quarantine/security settings دست‌کاری نمی‌شوند.

root عمومی ثابت: file SHA-256 برابر `bf34372f9eae519d13e4d635e352eb0a9fcc44b3fcc1007c5f3c078a03c349e7` و key ID برابر `98741d81da746d2e435302f90569911d` است؛ همان root در old main و main نهایی وجود دارد.

## ترتیب wrapper و مرز key

1. در `CI=true` یا `GITHUB_ACTIONS=true` فوراً رد می‌کند؛ هیچ identity از environment حذف نمی‌شود. خود signer قدیمی guard ضد CI ندارد؛ این محدودیت در wrapper صریح است.
2. روی ورودی عمومی، APPROVAL نهایی، tag/SHA، workflow path، دقیقاً ۱۰ نام/hash/size، فایل‌های عادی بدون symlink، installer/root/revocation/notices و شش فایل signer را کنترل می‌کند. Pythonها با `-I` اجرا می‌شوند تا moduleهای پوشهٔ دانلود یا cwd وارد مسیر import نشوند.
3. snapshot خصوصی از داده‌های عمومی می‌سازد. API رسمی run باید release.yml، push، tag v0.4.0، SHA دقیق و completed/success باشد؛ tag تازه از remote باید به SHA اعلام‌شده اشاره کند و در main باشد. noticeهای snapshot با source همان SHA مقایسه می‌شوند.
4. verifier و build script فقط پس از تطبیق با hash نسخهٔ بررسی‌شده اجرا می‌شوند. Go دقیق 1.27.3 تمام ۱۰ artifact snapshot را از Git archive پاک دوباره می‌سازد. سپس signer مستقل از ۶ فایل پین‌شده، جدا از source نامزد، محلی ساخته و hash می‌شود.
5. تنها پس از این مراحل پیام قطع شبکه و prompt **مسیر** release.key و certificate موجود ظاهر می‌شود. مسیرها باید عادی، nonsymlink و خارج از transfer/staging/output باشند. کلید copy یا وارد env نمی‌شود؛ فقط binary مستقل آن را با `-key` می‌خواند.
6. خروجی در directory خصوصی تازه با دقیقاً ۱۰ artifact ثابت و سه metadata خالی/ناموجود تولید می‌شود. `verify` نسبت به root ثابت و revocation الزامی است. شکست هر مرحله، تولید archive موفق را متوقف می‌کند.
7. archive برگشتی کوچک فقط سه metadata امضاشدهٔ manifest/certificate/SHA256SUMS و receipt/log عمومی و مراجع CANDIDATE/APPROVAL را دارد؛ ده artifact قبلاً در HQ موجودند و بایت‌هایشان ثابت و مستقل بررسی شده است. نسخهٔ کامل signed dist روی Mac می‌ماند؛ هیچ کلید یا مسیر کلید در receipt ثبت نمی‌شود. HQ ده artifact رسمیِ تأییدشده را با سه metadata برگشتی ترکیب و امضای همان محتوای کامل را مستقل verify می‌کند. outer tar انتقال لازم نیست deterministic باشد؛ bundle نصب نهایی بعداً در HQ بازسازی می‌شود.

دستورهای واقعی کنار کلید فقط این دو call هستند، با pathهای محلی انتخاب‌شده توسط کاربر:

```sh
"$TRUSTED_SIGNER_BIN" sign \
  -dir "$SIGNED_DIST" -version v0.4.0 -commit "$APPROVED_SHA" \
  -cert "$LOCAL_RELEASE_CERT" -key "$LOCAL_RELEASE_KEY" \
  -root-pub "$INDEPENDENT_PINNED_ROOT"
"$TRUSTED_SIGNER_BIN" verify \
  -dir "$SIGNED_DIST" -root-pub "$INDEPENDENT_PINNED_ROOT" \
  -revocations "$APPROVED_REVOCATIONS"
```

`mobile_sign_termux.sh` به checkoutِ candidate SHA وابسته است و signer را از همان candidate archive می‌سازد؛ خود clean rebuild اعتماد مستقل به signer ایجاد نمی‌کند. بنابراین مسیر اصلی این بسته از binary مستقل old-main استفاده می‌کند. نسخهٔ helper فقط برای مرجع عمومی همراه بسته است و کنار کلید اجرا نمی‌شود.

## اتصال نهایی انجام‌شده توسط HQ

این مراحل روی SHA دقیق main انجام شدند:۱۳workflow/۲۸job موفق، tag تغییرناپذیر v0.4.0، workflow رسمی `.github/workflows/release.yml` با run41046337283 و completed/success، و دریافت artifact `unsigned-release-candidate` از همان run. proof/official-candidate-binding.json تطابق بایتی هر۱۰asset را ثبت کرده است. فهرست زیر، قرارداد کنترل‌هایی است که پیش از تحویل نهایی اجرا شدند؛ پرکردن APPROVAL به‌تنهایی جای آن‌ها را نمی‌گیرد.

- `CANDIDATE` باید دقیقاً tag=v0.4.0، commit=SHA نهایی، signed=false و signing_boundary=external-offline باشد.
- هر ۱۰ فایل artifact رسمی باید بایت‌به‌بایت با build دوبارهٔ main نهایی، و root/revocation/install/notices با source همان SHA مطابق باشند. manifest `candidate/UNSIGNED-ASSETS.json` و proofها به همان SHA متصل بمانند.
- سپس `APPROVAL.json` با state=`APPROVED_FOR_OFFLINE_SIGNING`، approved_sha دقیق، candidate_workflow_run_id عددی، path صحیح، signer pin94 و دو boolean verified=true ثبت شود. این تغییر فقط بعد از تحقق شواهد مجاز است؛ پرکردن آن به‌تنهایی شواهد نمی‌سازد.
- بسته، manifest تمام فایل‌های عمومی و SHA-256 archive تازه ساخته شود. hash archive و SHA کامل مورد انتظار را مستقل در پیام تحویل بدهید. نسخهٔ آماده‌سازی قبلی قابل امضا معرفی نشود.

## پس از دریافت خروجی عمومی از Mac

HQ ابتدا اعضای archive کوچک برگشتی را پیش از استخراج از نظر نام‌های مجاز و نبود path traversal/symlink بررسی می‌کند و در directory تازه باز می‌کند. سپس یک signed dist کامل تازه با **ده artifact رسمیِ قبلاً بررسی‌شدهٔ SHA9c32ba3** و فقط سه metadata امضاشدهٔ برگشتی می‌سازد. SHA/tag manifest و trust files نسبت به تصمیم نهایی کنترل و با binary مستقل بالا **دوباره verify** می‌شوند. تمام ده artifact با rebuild همان SHA مقایسه می‌شوند؛ receipt صرفاً اطلاعات کمکی است و جای signature verification را نمی‌گیرد. سپس، روی محیط GNU موجود در HQ و بدون هیچ private key:

```sh
"$TRUSTED_SIGNER_BIN" verify \
  -dir "$SIGNED_PUBLIC/dist" -root-pub "$APPROVED_SOURCE/release/keys/root.pub" \
  -revocations "$APPROVED_SOURCE/release/keys/revocations.json"
SOURCE_DATE_EPOCH=0 bash "$REVIEWED_TOOLS/offline_bundle.sh" \
  "$SIGNED_PUBLIC/dist" "$APPROVED_SOURCE/release/keys/revocations.json" \
  "$APPROVED_SOURCE/install.sh" "$BUNDLE_OUT" "$SIGNED_PUBLIC/notices"
```

bundle builder به `manifest.json`، `SHA256SUMS`، `release-key.cert.json` و installerهای امضاشدهٔ دو معماری نیاز دارد. خودش signature را verify نمی‌کند؛ verify قبلی حذف نشود. خروجی `baft-offline-v0.4.0.tar.gz` و فایل `.sha256` است؛ بازسازی دوم باید بایت‌یکسان باشد. سپس signed assets و notices و bundle منتشر و `scripts/release/accept.sh v0.4.0` اجرا شوند. مجوز انتشار از قبل موجود است؛ deployment production جزو این تحویل نیست.

## کنترل انجام‌شده و محدودیت عملی

shell syntax و هر پنج بلوک Python داخل wrapper بررسی شدند. ۱۸ سناریوی structural/falsification بدون کلید شامل missing CANDIDATE، tag/SHA غلط، tamper، extra/signed/symlink artifact، root/notices/source/workflow غلط، module poisoning و CI refusal موفق‌اند؛ بازبینی مستقل نیز موارد اصلی را جدا تکرار کرد. گزارش‌های آزمون در `macos-signing-public-validation-tests.json` و `MACOS-WRAPPER-REVIEW.md` هستند. اجرای کامل native روی Mac و امضای واقعی هنوز انجام نشده و به‌عنوان PASS ادعا نشده است.

## فرمت برگشت کوچک و بازبینی تغییر محدود

نسخهٔ نهایی wrapper، پس از همان sign و verify کامل، فقط این۹عضو عمومی را در `signed-public-only.tar.gz` قرار می‌دهد: `dist/manifest.json`، `dist/release-key.cert.json`، `dist/SHA256SUMS`، `PUBLIC-RECEIPT.json`، `sign-public.log`، `verify-public.log`، `provenance-public.log`، `APPROVAL.json` و `CANDIDATE`. هیچ wildcard یا آرشیوکردن کل directory خروجی انجام نمی‌شود. ده فایل اصلی روی Mac و در HQ باقی می‌مانند. این تغییر فقط انتقال را کوچک می‌کند و منطق امضا، اعتبارسنجی، key یا signer را تغییر نمی‌دهد. گزارش تاریخی wrapper با hash708 مربوط به نسخهٔ قبل از این تغییر محدود است؛ تأیید نسخهٔ نهایی با hash2541 در بازبینی افزودهٔ metadata return ثبت می‌شود.
