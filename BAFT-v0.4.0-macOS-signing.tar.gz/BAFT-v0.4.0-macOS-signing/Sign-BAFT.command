#!/bin/bash
# Public preparation first; only the independently reviewed signer sees a key.
set -euo pipefail
umask 077
export PYTHONDONTWRITEBYTECODE=1
die() { printf '%s\n' "$*" >&2; exit 1; }
[[ "${GITHUB_ACTIONS:-}" != "true" && "${CI:-}" != "true" ]] || die "Offline signing is refused in CI; use the key holder's separate device."
[[ $# -eq 1 && "$1" =~ ^[0-9a-f]{40}$ ]] || die "Usage: bash Sign-BAFT.command FINAL_APPROVED_40_HEX_SHA"
BAFT_SHA=$1
BAFT_VERSION=v0.4.0
BAFT_BASE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)
command -v python3 >/dev/null || die "Install python3 before running this procedure."
# These checks precede architecture checks, network access, copying, and keys.
BAFT_RUN=$(python3 -I "$BAFT_BASE/validate_public.py" "$BAFT_BASE" "$BAFT_SHA")
[[ $(uname -s) == Darwin ]] || die "This entry point is for macOS only."
case $(uname -m) in
  arm64) BAFT_ARCH=arm64; BAFT_BIN_HASH=6a62824f4140a55562fdfe9a784f7b14f36c10031f5ea23fa04585e62646fa50 ;;
  x86_64) BAFT_ARCH=amd64; BAFT_BIN_HASH=34b8400e2c3416d5fd8cb513c647d3bdb49d132a8c55868010210535e3a1bd72 ;;
  *) die "Unsupported Mac architecture." ;;
esac
for BAFT_TOOL in git go curl shasum tar gzip; do
  command -v "$BAFT_TOOL" >/dev/null || die "Required public-preparation tool missing: $BAFT_TOOL"
done
BAFT_STAGE=$(mktemp -d "${TMPDIR:-/tmp}/baft-public-review.XXXXXXXX")
trap 'rm -rf "$BAFT_STAGE"' EXIT
# Rebuild and sign this private frozen public snapshot, not mutable downloads.
python3 -I - "$BAFT_BASE" "$BAFT_STAGE/candidate" <<'PY'
import pathlib, shutil, sys
NAMES = {f"{name}-linux-{arch}" for name in ("baft", "baft-pair", "baft-bcc", "baft-agent", "baft-install") for arch in ("amd64", "arm64")}
base, out = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2])
(out / "dist").mkdir(parents=True, mode=0o700)
(out / "notices").mkdir(mode=0o700)
for name in sorted(NAMES):
    shutil.copyfile(base / "candidate/dist" / name, out / "dist" / name)
for name in ("root.pub", "revocations.json", "install.sh", "CANDIDATE", "UNSIGNED-ASSETS.json"):
    shutil.copyfile(base / "candidate" / name, out / name)
for name in ("LICENSE", "COPYRIGHT", "THIRD_PARTY_LICENSES.md"):
    shutil.copyfile(base / "candidate/notices" / name, out / "notices" / name)
PY
[[ $(shasum -a 256 "$BAFT_STAGE/candidate/root.pub" | awk '{print $1}') == bf34372f9eae519d13e4d635e352eb0a9fcc44b3fcc1007c5f3c078a03c349e7 ]] || die "Frozen public root mismatch."
python3 -I - "$BAFT_STAGE/APPROVAL.json" "$BAFT_SHA" "$BAFT_RUN" <<'PY'
import json, pathlib, sys
approval = {"state": "APPROVED_FOR_OFFLINE_SIGNING", "version": "v0.4.0", "approved_sha": sys.argv[2], "candidate_workflow_run_id": int(sys.argv[3]), "candidate_workflow_path": ".github/workflows/release.yml", "trusted_signer_sha": "94c55dccf5af7cd126089374d991463931413121", "main_and_tag_verified": True, "all_required_gates_verified": True, "gate_decision_source": "validated HQ handoff record"}
pathlib.Path(sys.argv[1]).write_text(json.dumps(approval, indent=2) + "\n")
PY
printf '%s\n' 'بررسی عمومیِ tag، SHA، workflow و بازسازی؛ هنوز کلیدی لازم نیست.'
curl --fail --silent --show-error --location \
  "https://api.github.com/repos/zarkmakerburg/BAFT/actions/runs/$BAFT_RUN" > "$BAFT_STAGE/run.json"
python3 -I - "$BAFT_STAGE/run.json" "$BAFT_SHA" <<'PY'
import json, sys
r = json.load(open(sys.argv[1]))
assert r.get("path") == ".github/workflows/release.yml", "wrong candidate workflow"
assert r.get("head_sha") == sys.argv[2], "wrong candidate workflow SHA"
assert r.get("event") == "push", "candidate was not produced by the tag-push workflow"
assert r.get("head_branch") == "v0.4.0", "candidate run belongs to a different tag"
assert r.get("status") == "completed" and r.get("conclusion") == "success", "candidate workflow not successful"
PY
git clone --quiet https://github.com/zarkmakerburg/BAFT.git "$BAFT_STAGE/source"
git -C "$BAFT_STAGE/source" fetch --quiet --no-tags origin \
  refs/heads/main:refs/remotes/origin/main "refs/tags/$BAFT_VERSION:refs/tags/$BAFT_VERSION"
[[ $(git -C "$BAFT_STAGE/source" rev-parse "refs/tags/$BAFT_VERSION^{commit}") == "$BAFT_SHA" ]] || die "Final tag SHA mismatch."
git -C "$BAFT_STAGE/source" merge-base --is-ancestor "$BAFT_SHA" refs/remotes/origin/main || die "Final SHA is not on main."
git -C "$BAFT_STAGE/source" checkout --quiet --detach "$BAFT_SHA"
for BAFT_NOTICE in LICENSE COPYRIGHT THIRD_PARTY_LICENSES.md; do
  cmp -s "$BAFT_STAGE/candidate/notices/$BAFT_NOTICE" "$BAFT_STAGE/source/$BAFT_NOTICE" || die "Frozen notice differs from the approved Git source: $BAFT_NOTICE"
done
BAFT_VERIFY_HASH=$(shasum -a 256 "$BAFT_STAGE/source/scripts/release/verify_candidate_provenance.sh" | awk '{print $1}')
BAFT_BUILD_HASH=$(shasum -a 256 "$BAFT_STAGE/source/scripts/release/build.sh" | awk '{print $1}')
[[ "$BAFT_VERIFY_HASH" == 0fc65d8559a73f84e09aedd39a29c9bbacc941c09b6ddcfdedda0d5e7eb21a64 ]] || die "Provenance verifier needs a new independent review."
[[ "$BAFT_BUILD_HASH" == 71f55e5e3f1ea2917f1c0c47e2b38251f118f2c29717e7a9e211bf4cac2ed289 ]] || die "Build script needs a new independent review."
[[ $(awk '$1 == "go" {print $2; exit}' "$BAFT_STAGE/source/go.mod") == 1.27.3 ]] || die "Final source needs a different pinned Go version/review."
env GOTOOLCHAIN=go1.27.3 go version
bash "$BAFT_STAGE/source/scripts/release/verify_candidate_provenance.sh" \
  "$BAFT_STAGE/candidate" "$BAFT_VERSION" "$BAFT_SHA" | tee "$BAFT_STAGE/provenance.log"
# Compile locally to avoid executing a downloaded/quarantined candidate tool.
# All six source files were checked against the independent old-main pin.
cp -R "$BAFT_BASE/trusted-signer/source" "$BAFT_STAGE/signer-source"
(
  cd "$BAFT_STAGE/signer-source"
  env GOFLAGS= GOWORK=off GOEXPERIMENT= GOTOOLCHAIN=go1.27.3 \
    CGO_ENABLED=0 GOOS=darwin GOARCH="$BAFT_ARCH" GOAMD64=v1 GOARM64=v8.0 \
    go build -trimpath -buildvcs=false -ldflags='-s -w -buildid=' \
    -o "$BAFT_STAGE/baft-release" ./cmd/baft-release
)
[[ $(shasum -a 256 "$BAFT_STAGE/baft-release" | awk '{print $1}') == "$BAFT_BIN_HASH" ]] || die "Locally rebuilt independent signer digest differs; do not use a key."
python3 -I "$BAFT_BASE/validate_public.py" "$BAFT_BASE" "$BAFT_SHA" >/dev/null
BAFT_WORK=$(mktemp -d "$HOME/baft-signed-v0.4.0.XXXXXXXX")
mkdir -m 700 "$BAFT_WORK/export" "$BAFT_WORK/export/dist"
# Copy only the fixed public artifact set into a fresh private directory.
python3 -I - "$BAFT_STAGE" "$BAFT_WORK/export" <<'PY'
import pathlib, shutil, sys
NAMES = {f"{name}-linux-{arch}" for name in ("baft", "baft-pair", "baft-bcc", "baft-agent", "baft-install") for arch in ("amd64", "arm64")}
base, out = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2])
for name in sorted(NAMES):
    shutil.copyfile(base / "candidate/dist" / name, out / "dist" / name)
    (out / "dist" / name).chmod(0o400)
for name in ("root.pub", "revocations.json", "install.sh", "CANDIDATE"):
    shutil.copyfile(base / "candidate" / name, out / name)
out.joinpath("notices").mkdir(mode=0o700)
for name in ("LICENSE", "COPYRIGHT", "THIRD_PARTY_LICENSES.md"):
    shutil.copyfile(base / "candidate/notices" / name, out / "notices" / name)
shutil.copyfile(base / "APPROVAL.json", out / "APPROVAL.json")
PY
printf '%s\n' 'PASS: داده‌ها بازسازی شدند و signer مستقل آماده است. اکنون شبکه را قطع کنید.'
printf '%s' 'پس از قطع شبکه Enter بزنید: '
IFS= read -r BAFT_NETWORK_ACK
printf '%s' 'مسیر کامل release.key موجود، بدون کوتیشن: '
IFS= read -r BAFT_KEY
printf '%s' 'مسیر کامل release-key.cert.json موجود، بدون کوتیشن: '
IFS= read -r BAFT_CERT
for BAFT_LOCAL in "$BAFT_KEY" "$BAFT_CERT"; do
  [[ -f "$BAFT_LOCAL" && ! -L "$BAFT_LOCAL" ]] || die "Existing regular non-symlink local key/certificate required."
  BAFT_LOCAL_CANON=$(cd "$(dirname "$BAFT_LOCAL")" && pwd -P)/$(basename "$BAFT_LOCAL")
  case "$BAFT_LOCAL_CANON" in "$BAFT_BASE"/*|"$BAFT_WORK"/*|"$BAFT_STAGE"/*) die "Keep existing key/certificate outside the transfer and working directories." ;; esac
done
chmod 600 "$BAFT_KEY" "$BAFT_CERT"
BAFT_DIST="$BAFT_WORK/export/dist"
for BAFT_META in manifest.json SHA256SUMS release-key.cert.json; do
  [[ ! -e "$BAFT_DIST/$BAFT_META" && ! -L "$BAFT_DIST/$BAFT_META" ]] || die "Existing signing output refused."
done
"$BAFT_STAGE/baft-release" sign \
  -dir "$BAFT_DIST" -version "$BAFT_VERSION" -commit "$BAFT_SHA" \
  -cert "$BAFT_CERT" -key "$BAFT_KEY" -root-pub "$BAFT_WORK/export/root.pub" \
  > "$BAFT_WORK/export/sign-public.log"
"$BAFT_STAGE/baft-release" verify \
  -dir "$BAFT_DIST" -root-pub "$BAFT_WORK/export/root.pub" \
  -revocations "$BAFT_WORK/export/revocations.json" | tee "$BAFT_WORK/export/verify-public.log"
cp "$BAFT_STAGE/provenance.log" "$BAFT_WORK/export/provenance-public.log"
python3 -I - "$BAFT_WORK/export" "$BAFT_SHA" "$BAFT_ARCH" "$BAFT_BIN_HASH" <<'PY'
import hashlib, json, pathlib, sys
out = pathlib.Path(sys.argv[1])
files = {str(p.relative_to(out)): {"bytes": p.stat().st_size, "sha256": hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(out.rglob("*")) if p.is_file()}
receipt = {"version": "v0.4.0", "commit": sys.argv[2], "signer_source_sha": "94c55dccf5af7cd126089374d991463931413121", "signer_os": "darwin", "signer_arch": sys.argv[3], "signer_sha256": sys.argv[4], "verified": True, "private_keys_included": False, "files": files}
(out / "PUBLIC-RECEIPT.json").write_text(json.dumps(receipt, indent=2) + "\n")
PY
# Return only detached public signing metadata and evidence. HQ already has
# the exact ten candidate binaries and must verify them with this signed
# manifest/certificate/checksum set before making the installation bundle.
# Explicit members avoid returning the large binaries or unrelated files.
tar -czf "$BAFT_WORK/signed-public-only.tar.gz" -C "$BAFT_WORK/export" \
  dist/manifest.json dist/SHA256SUMS dist/release-key.cert.json \
  APPROVAL.json CANDIDATE PUBLIC-RECEIPT.json \
  sign-public.log verify-public.log provenance-public.log
printf '\n%s\n' 'PASS: امضا و verify موفق شد. فقط فایل زیر را تحویل بدهید؛ کلید روی دستگاه می‌ماند.'
printf '%s\n' "$BAFT_WORK/signed-public-only.tar.gz"
shasum -a 256 "$BAFT_WORK/signed-public-only.tar.gz"
