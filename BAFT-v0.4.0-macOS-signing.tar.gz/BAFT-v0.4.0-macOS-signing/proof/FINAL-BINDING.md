# Final public candidate binding

Version: `v0.4.0`. Accepted main commit: `9c32ba369fe2be2c549f2878d1de5dbf092c8f64`. Tree: `e065727d66ce97a917b9fc64e4e7ec7db9d73e3c`.

The immutable annotated tag object `69e77c655caa0fd0d18ca87226f20c23a2af2b35` points to that commit. [Official unsigned candidate workflow](https://github.com/zarkmakerburg/BAFT/actions/runs/41046337283) completed successfully for release.yml, tag-push v0.4.0 and the same commit. All ten downloaded artifacts match the independent main builds byte-for-byte; public root, revocations, installer and notices match accepted Git source. See [binding](official-candidate-binding.json), [run](official-candidate-run.json), [tag](official-tag.json), [13-workflow/28-job evidence](candidate-ci-evidence.json) and [reproducibility](release-reproducibility.json).

The approval is for independent-device signing only. Native Mac execution and a real production signature have not been performed here; publication requires the returned signatures to verify again against the retained ten approved artifacts and accepted trust files. No private key is included.

The historical wrapper review covers source hash708. The final limited metadata-return change uses wrapper hash `2541c1e8fd9631f53de4d4b01eb24470585d3e4205656cd206aeea60e29da5bb` and is approved in [the additional metadata-return review](METADATA-RETURN-REVIEW.md), including four actual archive-tail fixture checks. Its explicit nine-file return omits the already verified binaries; the trusted signing and verification calls remain unchanged.
