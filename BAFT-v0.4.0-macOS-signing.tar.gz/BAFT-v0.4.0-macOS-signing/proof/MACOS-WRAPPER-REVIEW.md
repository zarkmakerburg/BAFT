# Independent review of the macOS signing handoff wrapper

Reviewed on 2026-10-30 (Asia/Tehran), read-only with respect to the wrapper and validator. **No remaining concrete blocker found in the reviewed preparation/signing data flow.** This is conditional source approval for the handoff mechanism, not approval of the still-pending v0.4.0 tag/candidate, proof of a real Mac run, or evidence of a production signature.

Reviewed frozen bytes:

| File | SHA-256 |
|---|---|
| `macos-signing-staging/Sign-BAFT.command` | `7081498b34c23962ac2a6e6610ddc3ffd96c5f8d9e114b03dd5cbcff3355c800` |
| `macos-signing-staging/validate_public.py` | `c2a5be9350b42ae797d8ac5b7e59e4633ff0e274d1a320905a4c81237424f8ca` |

## Trust and public admission

- The initial validator runs before architecture checks, network access, copying and key prompts. The actual package remains `PREPARATION_NOT_APPROVED_FOR_SIGNING`, so it currently stops there. A valid final package must name the independently approved full SHA, v0.4.0, reviewed signer pin, final gate decision and official release workflow run ID. Those HQ decision fields are an authenticated handoff input; the wrapper does not independently recompute all thirteen workflow results.
- The wrapper rechecks the actual GitHub release run's workflow path, exact SHA, successful completion, push event and `head_branch=v0.4.0`; fetches the real tag and main; requires exact tag/SHA binding and main ancestry. Other tags at the same SHA do not satisfy the new tag-identity check.
- It copies the fixed ten unsigned artifacts and public files into a private snapshot **before** independently rebuilding. The known public-root hash is checked on that snapshot; the reviewed verifier binds its artifacts, root, revocations and installer to the clean approved source. All three copied notices are separately compared against that same approved Git checkout. The final signing input comes from this snapshot, so later mutation of the downloaded candidate is not substituted into signing.
- The validator refuses missing/extra/signed artifacts, symlinked ordinary inputs, wrong root, modified/extra signer source and extra notices. Notice copying now uses three fixed basenames rather than recursive copying. Exported approval is a newly constructed canonical public record from validated SHA/run values and fixed fields; raw mutable approval content is not copied into the return archive.
- Every Python invocation uses isolated mode `-I`, and copy blocks define the artifact names directly rather than injecting the transfer directory into `sys.path`. This prevents a `json.py`, `pathlib.py` or similar module in the caller's working directory or transfer directory from becoming executable signing-path code.

## Independent signer and key boundary

- The signer source remains separately pinned to `94c55dccf5af7cd126089374d991463931413121`, as reviewed in [TRUSTED-SIGNER-REVIEW.md](TRUSTED-SIGNER-REVIEW.md). The minimal six-file source set is exact and hash-checked; no arbitrary candidate signer is compiled or downloaded for execution.
- A local Go 1.27.3 Darwin build is required to match the independently prepared architecture-specific digest before any key prompt: arm64 `6a62824f4140a55562fdfe9a784f7b14f36c10031f5ea23fa04585e62646fa50`; amd64 `34b8400e2c3416d5fd8cb513c647d3bdb49d132a8c55868010210535e3a1bd72`. This also refuses altered copied signer source even if the mutable transfer changes after its first validation.
- The wrapper refuses `GITHUB_ACTIONS=true` or `CI=true` immediately. It does not remove those variables to bypass a CI restriction. The reviewed signer binary itself only uses the GitHub variable for provenance labeling; CI refusal therefore belongs to this reviewed wrapper and the operational isolation policy.
- Only after public checks and the signer rebuild does it ask the operator to disconnect networking and select the existing local release key and certificate. Nonregular/symlink key paths and paths within transfer/work/staging directories are refused. No root private key is needed.
- The signing output is a fresh private directory; artifact files are read-only and all three metadata paths must be absent, including dangling symlinks. The trusted signer alone reads the selected release key. It is then required to verify the signed output against the frozen pinned root and revocations before any public return archive is created. A failed sign or verify exits before the success/export step.
- The archive contains only the fixed copied public inputs, three signer-produced metadata files, public logs and generated public receipt. Key paths and private key bytes are not included. The archive is a transfer container, not the deterministic offline installation bundle; HQ must construct and verify that bundle later from these public signed outputs.

## Verification performed and practical limits

- Independently reran the synthetic public-input test script: **14/14 cases passed** in [macos-signing-independent-validation-tests.json](macos-signing-independent-validation-tests.json). It exercises qualified public data and refusal of pending approval, missing candidate, wrong tag/SHA, tampered/extra/signed/symlink artifact, wrong root, extra notice, modified/extra signer source and wrong workflow. Invalid cases invoke the actual wrapper and are rejected before public-preparation text and the key prompt.
- Independently ran shell syntax checking and confirmed the real preparation package's pending approval is refused before key handling. Source inspection found no Bash construct beyond macOS Bash 3.2's supported syntax, nor an incompatible use of BSD `mktemp`, `shasum`, `env`, `tar` or normal quoted paths. This is a portability inspection, not an execution result on macOS.
- A separate harmless poisoned-working-directory probe demonstrated that ordinary Python import executed the local fake `json.py`, while isolated `-I` imported only the standard library: [macos-wrapper-import-review.json](macos-wrapper-import-review.json). The wrapper now uses the safe form throughout.
- The positive macOS path, native Darwin execution, physical networking disconnection, availability/validity of the existing root-certified key, and a real signed return artifact **have not been executed or proved here**. Cross-built Mach-O file-format checks are not presented as native Mac execution. These are the remaining operational handoff steps after the real final tag/gate binding is supplied.
- Local OS, shell and toolchain installations, delivery of the wrapper's own authentic bytes, and the key holder's device are trusted inputs. The wrapper cannot secure a device already controlled by another process running as the same user, prove a physical air gap, or make a mutable unauthenticated archive into a trust root. The user must compare the handoff archive digest obtained through the HQ channel and use the separately supplied accepted SHA.

This reviewer did not edit the wrapper/validator, create a production signature, read an existing private key, publish an artifact, or change repository source, refs, configuration or external services.
