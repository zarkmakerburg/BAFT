# Independent review: compact public signing-metadata return

Reviewed on 2026-10-30 (Asia/Tehran). **Approved as a bounded transport change; no concrete blocker found.** This review does not establish a real Mac execution, a production signature, final release acceptance or publication.

The reviewed final wrapper is `Sign-BAFT.command`, SHA-256:

`2541c1e8fd9631f53de4d4b01eb24470585d3e4205656cd206aeea60e29da5bb`

Replacing only the new final archive comment/command with the old recursive export command reconstructs SHA-256 `7081498b34c23962ac2a6e6610ddc3ffd96c5f8d9e114b03dd5cbcff3355c800`, the exact wrapper previously reviewed in `MACOS-WRAPPER-REVIEW.md`. This byte-level check establishes that the public validation, source/provenance rebuild, independent signer build, key prompts, full signing, full verification and public receipt generation are unchanged. Only the post-verification return archive is smaller.

## What is returned

The actual tar command specifies exactly nine files:

- `dist/manifest.json`, `dist/SHA256SUMS`, `dist/release-key.cert.json`.
- `APPROVAL.json`, `CANDIDATE`, `PUBLIC-RECEIPT.json`.
- `sign-public.log`, `verify-public.log`, `provenance-public.log`.

It does not recursively include the working directory, binaries, key paths or other files. The full ten binaries still exist in the private local signing directory and are all read, signed through the manifest and verified there before this archive command is reached. A sign or verification failure remains fatal under `set -euo pipefail` and cannot reach the return step.

Omitting unchanged binaries does not weaken the signature binding: the reviewed `SignDir` hashes the actual artifact names, sizes and bytes into the manifest and checksum list; the release key signs the manifest, including the checksum-file hash. The independently root-signed certificate authenticates that release key. `VerifyDir` checks root/certificate/revocations, signature, version/commit syntax, checksum binding and every present artifact's name, size and hash, and refuses missing/extra artifacts. The receiving HQ must reconstruct the full distribution before invoking this verifier.

## Required receiving procedure

1. Admit only ordinary, relative, expected archive members in a fresh directory; refuse absolute/traversing paths, links and special entries. The fixed sender allowlist is not a reason to trust an arbitrary uploaded archive.
2. Copy the exact ten retained official candidate assets already bound to accepted main `9c32ba369fe2be2c549f2878d1de5dbf092c8f64` and tag `v0.4.0` into a new distribution directory. Add only the three actual returned signing metadata files. Keep logs, public roots, receipts and approval records outside this directory.
3. Independently verify that complete distribution with the separately reviewed signer against the committed public root and current committed revocations. Require the authenticated manifest to name exactly `v0.4.0` and the accepted full SHA, and compare all ten assets with the approved candidate/rebuild. `VerifyDir` accepts syntactically valid version/commit values, so the caller must enforce the expected values explicitly.
4. Only after those checks may HQ build/rebuild the deterministic offline bundle, publish the verified signed assets and perform published-release acceptance.

`PUBLIC-RECEIPT.json`'s `verified` boolean, public logs, an approval record, an outer archive checksum or a copied `CANDIDATE` origin file are not cryptographic release proof. The receipt retains the original local working-output inventory, including binary digests; omission of those binaries from the transfer must not be mistaken for their absence from local signing/verification. The original `CANDIDATE` describes the unsigned input; actual returned signature metadata and independent complete-distribution verification decide the signed result.

## Checks performed

- `bash -n` passed on the final wrapper.
- The previous frozen wrapper hash was reconstructed exactly by reversing only the archive-tail change.
- Executed the actual final archive tail in a disposable local fixture with clearly synthetic public text, a dummy binary of roughly 1.26 MB, and dummy private-key filenames containing no actual key material. **Four checks passed**: exact nine-member ordinary/relative allowlist; byte-identical preservation of all nine public files; rejection of missing certificate metadata; rejection of a missing verification log. Both missing-input cases exited 2 before a success message. The synthetic nine-file archive was 418 bytes; that is a fixture result, not an actual signed-package size.
- Evidence: `metadata-return-review-tests.json`.

The fixture ran on Linux with the available tar/bash. The changed command uses existing standard `tar -czf`/`-C` flags and explicit file members; no new GNU-only option was added. Native macOS execution, physical network disconnection, existing key availability and a production signing result remain unexecuted here. No real key, signature, repository source/ref, environment configuration or external service was changed by this review.
