# بازبینی نهایی زیرگیت انتشار، backup و update

تاریخ بازبینی: ۲۰۲۶-۱۰-۳۰ به وقت تهران. SHA آزموده‌شده: `aa94669d090d2fc3205ca5f76e66ef3a5bd86e06`؛ tree: `81fffc891778ef5f9f803d47fdf60eb0bd2cb4ca`؛ Go `1.27.3`. checkout مستقل `/tmp/baft-release-aa94669` هنگام بازبینی clean و روی همین SHA بود. این گزارش به‌تنهایی تصمیم GO برای v0.4.0 یا بستن #269 نیست.

| مورد | نتیجهٔ بازبینی مستقل |
|---|---|
| بازتولید artifactهای واقعی unsigned v0.4.0 | هر ۱۰ فایل در **هر دو** directory دوباره SHA-256 و size شدند؛ هر ۲۰ خواندن با `../final-aa94669/release-reproducibility.json` مطابق بود. |
| provenance | اجرای بدون تغییر `tests/release/provenance_check.sh`، exit 0: rebuild از Git archive پاک با Go پین‌شده، تطبیق ۱۰ asset؛ رد tag ناموجود، tag با SHA دیگر، SHA نادرست، root/installer متفاوت و binary دست‌کاری‌شده. نسخهٔ fixture برابر `v0.9.8-provenance-test` است؛ این شاهد امضای نهایی v0.4.0 نیست. |
| trust و dry run | اجرای بدون تغییر `scripts/release/dry_run.sh`، exit 0: ۱۰ artifact یکسان در دو build؛ امضا و verify با کلید دورریختنی؛ تمام هفت negative مورد انتظار رد شدند و downgrade صریح پذیرفته شد. هیچ کلید آزمایشی trust root انتشار رسمی نشد. |
| backup/restore/update | فایل‌های JSONL مستقل بازشماری شدند: **۱۱۴ تست سطح اول، ۲۳۶ PASS با subtestها، صفر FAIL/SKIP**، تحت race detector. شامل backup رمز‌شده، انتقال و restore واقعی CLI، lock بین processها، state و high-watermark، tamper/key/schema، atomic/journal failures و Update Center فعلی است. CLI self-updater/UUM یا موتور خارجی از این نتیجه استنباط نمی‌شود. |
| migration و rollback تاریخی BCC | Gamma اصلی با ref تاریخی ازقبل موجود `v0.3.7`، pin دقیق `94c55dcc…`، exit 0: migration، رد اجرای binary قدیمی روی schema جدید، cold-snapshot rollback و re-upgrade. شکست اولیهٔ fixture با نبود ref در clone حفظ شده است. |
| upgrade تاریخی tunnel | Gamma namespace اصلی، exit 0: pairing و payload واقعی روی کد `94c55dcc…`، سپس توقف و اجرای کد `aa94669…` با همان config/Noise keys؛ چهار اتصال هرکدام ۱ MiB؛ TCP/22 مسدود و سرویس نامرتبط 2053 محفوظ. build info هر دو binary، SHA صحیح و `vcs.modified=false` را نشان می‌دهد. این مسیر upgrade متوقف‌شده است؛ socket فعال یا systemd را اثبات نمی‌کند. |
| native installer و rollback | اجرای اصلی `install_two_roles.sh` روی PID1 واقعی systemd 255، exit 0؛ ۱۶ اتصال و ۵۸٬۷۲۰٬۲۵۶ بایت payload hash‌شده؛ rerun، repair، consent، upgrade، downgrade refusal و rollback دو binary خراب. نسخه‌های `v0.0.1-ci` و `v0.0.2-ci` هر دو از AA ساخته شده‌اند؛ historical compatibility را Gamma مستقل می‌سنجد. |
| uninstall اصلی | اجرای pristine AA پیش از uninstall در setup سرویس `Type=simple` شکست خورد؛ PID شروع شده بود ولی Python هنوز socket را bind نکرده بود. این FAIL حذف یا PASS اعلام نشده است. |
| uninstall با readiness اصلاح‌شده | overlay محدود، exit 0، روی systemd واقعی: preservation، crash/restore/resume، reinstall بدون re-pair، anti-rollback، emergency backup پیش از حذف BCC، purge و fresh re-pair موفق شدند. فقط قبل از اولین `hand_ok`، حداکثر ۵ ثانیه برای **echo واقعی** صبر می‌کند؛ snapshotها و همهٔ assertions بعدی عوض نشده‌اند. HQ اکنون همین patch را در checkout کاری اعمال کرده؛ با حذف insertion، فایل دقیقاً برابر pristine AA است. مناسب ادغام به‌عنوان اصلاح fixture است؛ شاهد pristine SHA آینده محسوب نمی‌شود. |

شواهد و حدود دقیق در [RELEASE-RESULT.md](RELEASE-RESULT.md)؛ digest فایل‌های بازبینی‌شده و نتیجهٔ hash مجدد در [release-audit-evidence.json](release-audit-evidence.json) ثبت شده است. این بازبینی هیچ دستور نصب/حذف جدید، شبکهٔ میزبان، cgroup میزبان، daemon، tag، merge یا انتشار اجرا نکرد.

## شروطی که هنوز مانع انتشار نهایی‌اند

فهرست دقیق workflowها و شرط dispatch هرکدام در [FINAL-GATE-INVENTORY.md](FINAL-GATE-INVENTORY.md) آمده است؛ اصلاح پذیرش پیشنهادشده اکنون recovery و shared-ingress را نیز برای tag حامل فایل الزامی می‌کند. تست RED حذف‌شدن سطر gate در نسخهٔ قبلی را بازتولید کرد و ۵۶ رخداد PASSِ آزمون‌های gate پس از اصلاح ثبت شد.

1. پذیرش ترکیبی BCC→Plan→Agent→shared transport→public ingress/nft→payload→authenticated Receipt→Verified، همراه با failure/restart/retire و حفظ tenantهای دیگر، جداگانه باید کامل شود. موفقیت زیرگیت‌های این گزارش جای آن نیست.
2. SHA نهایی پس از ادغام تغییرات باید تثبیت شود؛ شواهد AA خودکار به SHA دیگر منتقل نمی‌شوند. candidate واقعی از tag روی main باید با همان SHA و toolchain مستقل بازسازی و کنترل شود. final tag/candidate v0.4.0 هنوز ساخته نشده است.
3. مرز امضا **external/offline** است، طبق [release/SIGNING.md](/workspace/BAFT/release/SIGNING.md) و `release.yml`. workflow فقط unsigned candidate می‌سازد و signing credential دریافت نمی‌کند. امضاکنندهٔ مستقل با کد بازبینی‌شده در commit ثابت، کلید release موجود و root-certified، certificate معتبر و revocation list جاری لازم است. هیچ trusted production signer متصل و تأییدشده‌ای در این شواهد وجود ندارد؛ کلیدها/secretها برای کشف محتوا خوانده نشده‌اند. مجوز مالک جای دسترسی به امضاکننده را نمی‌گیرد.
4. manifest نهایی باید SHA نهایی را حمل کند؛ assetهای نهایی باید با root پین‌شده و revocation verify شوند؛ offline bundle باید بازسازی بایت‌یکسان و کنترل شود؛ سپس انتشار و `scripts/release/accept.sh v0.4.0` روی tag/main و CI همان SHA لازم است. آن acceptance، published assetها را می‌خواند و پیش از انتشار قابل PASS نهایی نیست.

مجوز جدید مالک برای merge، tag و release وجود دارد و نیاز به تکرار اجازه نیست. هنوز production deployment مجاز نشده و هیچ اقدام production انجام نشده است. تنها بخش نیازمند محیط بیرونی در این زیرگیت، **امضای واقعی با مرجع offline موجود** است؛ باقی موارد، تکمیل شواهد/آماده‌سازی و اقدامات مجاز HQ پس از رفع مانع ترکیبی‌اند.

متادیتای عمومی revocation repository دارای sequence 1 و تاریخ انقضای `2027-03-31T05:08:48Z` است؛ این بازبینی صرفاً payload عمومی را خواند. اعتبار امضای آن نسبت به root پین‌شده باید همراه verify انتشار نهایی ثابت شود.

## به‌روزرسانی artifact نامزد نهایی

بازسازی و provenance اکنون برای SHA نهایی `ced78f509f2acc8b3cc08fb94d1baa97092191c7` نیز مستقل انجام و PASS شد: [گزارش دقیق](../final-ced78f5/RELEASE-PROVENANCE.md). هر ۱۰ artifact در دو build همان SHA یکسان‌اند. این به‌روزرسانی شواهد تاریخی/installer/backup AA را به‌عنوان اجرای SHA تازه معرفی نمی‌کند و مرز امضای offline و پذیرش ترکیبی را تغییر نمی‌دهد.
