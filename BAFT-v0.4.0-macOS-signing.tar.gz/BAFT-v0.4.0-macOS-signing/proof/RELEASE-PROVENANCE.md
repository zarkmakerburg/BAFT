# artifact و provenance روی main نهایی

تاریخ: ۲۰۲۶-۱۰-۳۰ به وقت تهران. SHA دقیق main پس از merge PR #291: `9c32ba369fe2be2c549f2878d1de5dbf092c8f64`؛ tree: `e065727d66ce97a917b9fc64e4e7ec7db9d73e3c`.

- clone استاندارد مستقل `/tmp/baft-release-main-9c32ba3` پیش و پس از اجرا clean و روی SHA دقیق بود؛ worktree جدید ساخته نشد.
- `scripts/release/build.sh v0.4.0` دو بار، بدون تغییر، exit 0؛ **۱۰/۱۰ artifact بایت‌یکسان در دو build**. هر ۱۰ فایل با build قبلی `ced78f5` نیز یکسان‌اند؛ این نتیجه پس از اجرای تازه روی main محاسبه شد و از tree equality فرض نشده است.
- `tests/release/provenance_check.sh` بدون تغییر، exit 0؛ ۱۰ asset از Git archive پاک روی Go `1.27.3` بازسازی و تطبیق داده شد. شش falsification با دلایل مورد انتظار رد شدند.
- `GOMAXPROCS=2`، `GOFLAGS=-p=2`، umask `0022`. source/command/exit/duration در [metadata](release-execution-metadata.json)، hash/size تک‌تک assetها در [manifest محلی](release-reproducibility.json) و خروجی کامل در [provenance.log](provenance.log).

فایل‌ها هنوز unsigned هستند. این زیرکار tag، امضا یا انتشار انجام نداد؛ پذیرش گیت‌های hosted main، tag و candidate رسمی، امضای مستقل و verify/accept نهایی جداگانه دنبال می‌شوند. provenance fixture، اعتبار tag یا production signature واقعی v0.4.0 را ادعا نمی‌کند.
