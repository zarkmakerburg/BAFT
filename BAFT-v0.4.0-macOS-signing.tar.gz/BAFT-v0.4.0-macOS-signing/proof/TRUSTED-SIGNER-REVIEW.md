# Independent review of the immutable BAFT signer

Reviewed on 2026-10-30 (Asia/Tehran). This is a new independent source review for the current handoff, not a claim of earlier owner approval or production-key access.

**Recommendation:** HQ can pin `TRUSTED_SIGNER_SHA=94c55dccf5af7cd126089374d991463931413121` for this signing handoff, build its signer on a keyless machine with the already checked Go 1.27.3 toolchain, record the native binary hash, and transfer that reviewed signer separately from the unsigned candidate. The review found no concrete signing-key exfiltration or signature-verification blocker in that small source surface under the input/isolation conditions below. This recommendation does not approve the release candidate, supply a key/certificate, or authorize a deployment.

## Source reviewed and comparison

Read the complete `cmd/baft-release/main.go` and `internal/release/release.go`, plus the mobile helper, provenance verifier, bundle builder and signing-boundary document. Their bytes at the proposed pin equal their bytes at candidate `ced78f509f2acc8b3cc08fb94d1baa97092191c7`. `go.sum` is unchanged. `go.mod` changed only its Go directive from 1.27.1 to 1.27.3; using Go 1.27.3 to build the old source satisfies that minimum.

| Public source | SHA-256 at both commits |
|---|---|
| `cmd/baft-release/main.go` | `a46b57921e888d9f9da2cf74ba777ecc68c9188cb8717112502361d60380fc4f` |
| `internal/release/release.go` | `830050f50a0abd4b4288d0f82321812e321492a9f48e4ee3c2936a70522727a9` |
| `scripts/release/mobile_sign_termux.sh` | `683b01e25e644e7641541da7b2f4d410b78266c278f1ee7dd1f7a014f50975a5` |
| `scripts/release/verify_candidate_provenance.sh` | `0fc65d8559a73f84e09aedd39a29c9bbacc941c09b6ddcfdedda0d5e7eb21a64` |
| `scripts/release/offline_bundle.sh` | `5ac329fa5426b4b6b3c89171e26e9b2062f39ab9c97551d1d5fcfb0e3fd95fcd` |
| `release/SIGNING.md` | `8cadca77c81222b78833b8ea5e2274bc9a97c6dd548d65ae91a1a8db688f4a46` |

No preexisting immutable signer SHA or binary-hash approval was found in the public signing documents. The recommendation above follows this actual review; byte equality with old main alone was not treated as trust approval.

## Key access and control flow

- `cmd/baft-release` imports only the Go standard library and the one local `internal/release` package; that package itself imports only the standard library. The reviewed path contains no network client, subprocess execution, plugin loading, generated-code execution or artifact execution.
- `sign` reads the operator-selected release key using `-key`, or an environment fallback when that flag is absent; use the explicit file flag in the isolated signer. It reads the selected public root and certificate and streams artifact bytes into SHA-256. The private seed is decoded to Ed25519 in memory, never formatted into the manifest or success/error logs. Go memory is not explicitly zeroized; process/device isolation remains necessary.
- Signing writes only `SHA256SUMS`, `manifest.json` and `release-key.cert.json` inside the selected distribution directory. Other subcommands include root-key and key-generation operations, but the release handoff needs neither `keygen`, `certify` nor `revoke`, and must not mount a root private key.
- DSSE signs exact payload bytes with a length-delimited payload type, separate key-certificate/manifest/revocation types, and one Ed25519 signature. Certificate verification checks the pinned root, release purpose/schema, key-ID/public-key consistency and a positive validity window bounded to 400 days. The certificate key must match the private signing key before metadata is written.
- `SignDir` requires a syntactically valid release version and full lowercase 40-character commit. It scans regular artifact files with safe basename syntax `<prefix>-linux-<amd64|arm64>`, hashes all of them and sorts them. It does not execute their bytes.
- `VerifyDir` requires a root-signed, correctly shaped, unexpired revocation list; refuses a revoked release key; verifies certificate and manifest signatures and matching key IDs; checks manifest signing time within certificate validity; verifies the exact checksum-file digest and all artifact sizes/hashes; refuses unknown or missing artifact files. An explicit local trust state additionally rejects revocation-sequence rollback, unapproved version downgrade and same-version/different-commit replacement.

## Conditions the handoff must enforce

1. **Admission is external to the signer.** It does not fetch Git, bind a tag to main, authenticate a GitHub run, or independently rebuild the application. Do all of that on a keyless machine first, using the finally accepted SHA. A caller-controlled `-commit` string alone is not provenance evidence.
2. **Exact artifact set is external.** The filename regex is a syntax allowlist, not the fixed set of ten BAFT artifacts. The independent clean-source rebuild must establish the exact ten names, sizes and hashes before transfer; freeze the copied input directory after that check.
3. **Use a new private output directory of ordinary files.** The three metadata basenames are skipped during artifact scanning, and writes use ordinary filesystem calls. Existing metadata symlinks could redirect writes; existing metadata could also be overwritten. Require all three metadata paths to be absent, including dangling symlinks, reject symlinked input directories/files, and admit no other writer. The mobile helper already performs the relevant absence/symlink checks. The standalone binary is not a general hostile-filesystem sandbox.
4. **Always verify after signing, before returning/publishing.** `sign` itself does not read revocations and does not enforce current certificate time. `verify` supplies those mandatory checks, including whether the new manifest's signing time falls inside the certificate window. Any failed sign/verify leaves the output in an unaccepted state; quarantine/discard that attempt instead of calling it a release. Three metadata writes are not one atomic transaction.
5. **Keep provenance honest.** The reviewed binary itself has no CI-refusal guard: `GITHUB_ACTIONS=true` changes its provenance label rather than blocking signing. The handoff wrapper must refuse `GITHUB_ACTIONS=true` or `CI=true` early and must not mask that environment to get past a guard. On the independent offline device, the CLI records builder `local` and the signer runtime Go version. Do not fabricate GitHub Actions variables to make an offline signature appear to be an Actions build attestation. Independently recorded build/run/source evidence remains a separate public input.
6. **Use the independently reviewed binary near the key.** `mobile_sign_termux.sh` requires its own checkout HEAD to equal the candidate SHA and compiles the signer from that candidate archive. This protects against dirty/untracked source but does not establish independent signer trust. For a signer pinned to old main, use the prepared trusted binary directly after keyless candidate admission, rather than executing the candidate helper beside the production key. Running the helper would require a separate affirmative review/selection of that helper and its compiled signer source, not automatic inheritance from candidate acceptance.
7. **No key transfer or replacement root.** Return only public signed assets, public verification logs and public certificate/root/revocation data. Keep `release.key` and every root private key off GitHub, chat and the transfer archive. An unavailable existing certified release key is a real external dependency; generating a fresh root does not resolve it.

## Supported signing/verification calls

Using paths chosen by the key holder, after the admission and directory checks above:

```sh
if [ "${GITHUB_ACTIONS:-}" = true ] || [ "${CI:-}" = true ]; then
  printf '%s\n' "Use the key holder's independent offline device, not CI." >&2
  exit 1
fi

"$TRUSTED_SIGNER_BIN" sign \
  -dir "$SIGNED_DIST" -version "$APPROVED_TAG" -commit "$APPROVED_SHA" \
  -cert "$LOCAL_RELEASE_CERT" -key "$LOCAL_RELEASE_KEY" \
  -root-pub "$INDEPENDENT_PINNED_ROOT"

"$TRUSTED_SIGNER_BIN" verify \
  -dir "$SIGNED_DIST" -root-pub "$INDEPENDENT_PINNED_ROOT" \
  -revocations "$APPROVED_REVOCATIONS"
```

The placeholders are deliberate operator-local selectors, not values recovered from a secret store. A valid certificate is public release metadata; its matching private key remains local. GNU-tar-dependent offline-bundle creation can occur later on the keyless HQ machine from the returned public signed files, using the reviewed immutable bundle script, followed by signature verification and deterministic rebuild comparison.

This was a source review only. No private key was read, no signer executable or signature was created by this reviewer, and no source, Git ref, workflow, environment setting or external state was changed.
