#!/usr/bin/env python3
"""Admit public signing inputs only; never open a private-key path."""
import hashlib
import json
import pathlib
import re
import sys

TAG = "v0.4.0"
SIGNER_SHA = "94c55dccf5af7cd126089374d991463931413121"
ROOT_HASH = "bf34372f9eae519d13e4d635e352eb0a9fcc44b3fcc1007c5f3c078a03c349e7"
SOURCE_HASHES = {
    "cmd/baft-release/main.go": "a46b57921e888d9f9da2cf74ba777ecc68c9188cb8717112502361d60380fc4f",
    "internal/release/release.go": "830050f50a0abd4b4288d0f82321812e321492a9f48e4ee3c2936a70522727a9",
    "go.mod": "488a574c2a31f798b151a31d14ba5c64f6ccbd2c83d94c3b188c8c63e44b187c",
    "go.sum": "e47b64abd6c3164ed87896bf0a3427170850316bebdaee6e73aeadc7a49f3e02",
    "LICENSE": "8486a10c4393cee1c25392769ddd3b2d6c242d6ec7928e1414efff7dfb2f07ef",
    "COPYRIGHT": "dd7720ff2fd3be73888f03499353b691348d4578ebeb919777d9936ee59ee3d9",
}
NAMES = {f"{name}-linux-{arch}" for name in ("baft", "baft-pair", "baft-bcc", "baft-agent", "baft-install") for arch in ("amd64", "arm64")}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def ordinary(path):
    require(path.is_file() and not path.is_symlink(), f"missing/nonregular/symlink file: {path.name}")
    return path.read_bytes()


def digest(path):
    return hashlib.sha256(ordinary(path)).hexdigest()


def validate(base, sha):
    require(re.fullmatch(r"[0-9a-f]{40}", sha), "approved full lowercase SHA is required")
    require(base.is_dir() and not base.is_symlink(), "invalid package directory")
    approval = json.loads(ordinary(base / "APPROVAL.json"))
    require(approval.get("state") == "APPROVED_FOR_OFFLINE_SIGNING", "PREPARATION ONLY: final main/tag/gate binding has not been supplied")
    require(approval.get("approved_sha") == sha and approval.get("version") == TAG, "approval SHA/tag mismatch")
    require(approval.get("trusted_signer_sha") == SIGNER_SHA, "independent signer pin mismatch")
    require(approval.get("main_and_tag_verified") is True and approval.get("all_required_gates_verified") is True, "final main/tag/CI evidence missing")
    require(approval.get("candidate_workflow_path") == ".github/workflows/release.yml", "candidate workflow path mismatch")
    run_id = approval.get("candidate_workflow_run_id")
    require(type(run_id) is int and run_id > 0, "official candidate workflow run ID missing")

    candidate = base / "candidate"
    dist = candidate / "dist"
    for directory in (candidate, dist, candidate / "notices", base / "trusted-public", base / "trusted-signer", base / "trusted-signer/source"):
        require(directory.is_dir() and not directory.is_symlink(), f"invalid/symlink directory: {directory.name}")
    fields = {}
    for line in ordinary(candidate / "CANDIDATE").decode().splitlines():
        key, value = line.split("=", 1)
        require(key not in fields, "duplicate candidate metadata key")
        fields[key] = value
    require(fields == {"tag": TAG, "commit": sha, "signed": "false", "signing_boundary": "external-offline"}, "CANDIDATE tag/SHA/unsigned boundary mismatch")
    require({x.name for x in dist.iterdir()} == NAMES, "expected exactly ten unsigned artifacts; signed/unknown entries refused")
    manifest = json.loads(ordinary(candidate / "UNSIGNED-ASSETS.json"))
    require(manifest.get("source_sha") == sha and manifest.get("version") == TAG, "unsigned manifest SHA/tag mismatch")
    assets = manifest.get("artifacts", [])
    require(len(assets) == 10 and {x.get("artifact") for x in assets} == NAMES, "unsigned manifest artifact set mismatch")
    for asset in assets:
        path = dist / asset["artifact"]
        data = ordinary(path)
        require(len(data) == asset["bytes"] and hashlib.sha256(data).hexdigest() == asset["sha256"], f"artifact size/hash mismatch: {path.name}")
    installer = ordinary(candidate / "install.sh")
    for arch in ("amd64", "arm64"):
        require(installer == ordinary(dist / ("baft-install-linux-" + arch)), "installer copy mismatch")
    for root in (candidate / "root.pub", base / "trusted-public/root.pub"):
        require(digest(root) == ROOT_HASH, "independent pinned public root mismatch")
    require(ordinary(candidate / "revocations.json") == ordinary(base / "trusted-public/revocations.json"), "public revocations transfer mismatch")
    require({x.name for x in (candidate / "notices").iterdir()} == {"LICENSE", "COPYRIGHT", "THIRD_PARTY_LICENSES.md"}, "unexpected notice files refused")
    for notice in ("LICENSE", "COPYRIGHT", "THIRD_PARTY_LICENSES.md"):
        ordinary(candidate / "notices" / notice)

    source = base / "trusted-signer/source"
    actual = set()
    for path in source.rglob("*"):
        require(not path.is_symlink(), "symlink in independent signer source")
        if path.is_file():
            actual.add(str(path.relative_to(source)))
        else:
            require(path.is_dir(), "special entry in independent signer source")
    require(actual == set(SOURCE_HASHES), "independent signer source contains missing/extra files")
    for name, expected in SOURCE_HASHES.items():
        require(digest(source / name) == expected, f"independent signer source changed: {name}")
    return run_id


if __name__ == "__main__":
    try:
        require(len(sys.argv) == 3, "usage: validate_public.py PACKAGE_DIR APPROVED_SHA")
        print(validate(pathlib.Path(sys.argv[1]), sys.argv[2]))
    except (ValueError, KeyError, TypeError, OSError) as error:
        print("REFUSED before key prompt: " + str(error), file=sys.stderr)
        sys.exit(1)
