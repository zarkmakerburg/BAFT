BAFT v0.4.0 offline bundle

On a server with no internet access (Debian/Ubuntu with python3 and openssl):

  tar -xzf baft-offline-v0.4.0.tar.gz
  cd baft-offline-v0.4.0
  sudo bash install.sh --offline . --role ex --public-address HOST_OR_IP
  # or:  sudo bash install.sh --offline . --agent-only --bcc-url ... --node-id ...

The release is verified against the root key pinned in install.sh and the
bundled revocation list (which expires; use a fresh bundle after that).
Compare the archive with the .sha256 published next to it before use.
